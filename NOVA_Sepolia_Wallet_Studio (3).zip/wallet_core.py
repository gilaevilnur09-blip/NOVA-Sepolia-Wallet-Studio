import json
from pathlib import Path
from web3 import Web3
from eth_account import Account

Account.enable_unaudited_hdwallet_features()

def create_encrypted_wallet(password: str):
    if not password or len(password) < 8:
        raise ValueError("Password must contain at least 8 characters.")
    account = Account.create()
    encrypted = Account.encrypt(account.key, password)
    return account, encrypted

def save_keystore(encrypted: dict, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(encrypted, indent=2), encoding="utf-8")

def load_keystore(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))

def load_encrypted_wallet(encrypted: dict, password: str):
    private_key = Account.decrypt(encrypted, password)
    return Account.from_key(private_key)

def get_balance(w3, address: str) -> float:
    if not Web3.is_address(address):
        raise ValueError("Invalid Ethereum address.")
    return float(Web3.from_wei(w3.eth.get_balance(Web3.to_checksum_address(address)), "ether"))

def build_and_sign_transfer(w3, private_key: str, recipient: str, amount_eth: float) -> str:
    if not Web3.is_address(recipient):
        raise ValueError("Invalid recipient address.")
    if amount_eth <= 0:
        raise ValueError("Amount must be greater than zero.")
    account = Account.from_key(private_key)
    sender = account.address
    value = Web3.to_wei(amount_eth, "ether")
    balance = w3.eth.get_balance(sender)
    if balance < value:
        raise ValueError("Insufficient Sepolia ETH for amount and gas.")
    nonce = w3.eth.get_transaction_count(sender)
    tx = {
        "chainId": w3.eth.chain_id,
        "nonce": nonce,
        "to": Web3.to_checksum_address(recipient),
        "value": value,
        "gas": 21000,
        "gasPrice": w3.eth.gas_price,
    }
    signed = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    return tx_hash.hex()
