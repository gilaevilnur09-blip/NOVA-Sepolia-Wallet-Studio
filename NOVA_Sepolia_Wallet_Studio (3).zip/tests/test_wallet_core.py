import pytest
from eth_account import Account
from wallet_core import create_encrypted_wallet, load_encrypted_wallet, get_balance, build_and_sign_transfer

def test_create_wallet_returns_address_and_encrypted_data():
    account, encrypted = create_encrypted_wallet("correct horse battery")
    assert account.address.startswith("0x")
    assert "crypto" in encrypted or "Crypto" in encrypted

def test_encrypted_wallet_unlocks_with_correct_password():
    account, encrypted = create_encrypted_wallet("correct horse battery")
    restored = load_encrypted_wallet(encrypted, "correct horse battery")
    assert restored.address == account.address

def test_wrong_password_is_rejected():
    _, encrypted = create_encrypted_wallet("correct horse battery")
    with pytest.raises(Exception):
        load_encrypted_wallet(encrypted, "wrong password")

def test_balance_rejects_invalid_address():
    with pytest.raises(ValueError):
        get_balance(None, "not-an-address")

def test_transfer_rejects_invalid_recipient():
    account = Account.create()
    with pytest.raises(ValueError):
        build_and_sign_transfer(None, account.key.hex(), "bad-address", 0.01)

def test_transfer_rejects_zero_amount():
    account = Account.create()
    with pytest.raises(ValueError):
        build_and_sign_transfer(None, account.key.hex(), "0x0000000000000000000000000000000000000001", 0)
