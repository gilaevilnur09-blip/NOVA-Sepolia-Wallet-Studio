# NOVA Wallet — Sepolia Testnet

A polished educational Ethereum wallet built with Python, Streamlit and web3.py.

## Features
- Generate an Ethereum account.
- Encrypt its private key into a local JSON keystore.
- Unlock the keystore with its password.
- Connect to Sepolia and read ETH balance.
- Send Sepolia test ETH and open the transaction on Sepolia Etherscan.
- Six offline unit tests.

## Setup (5 steps)

1. Install **Python 3.10+** and **Visual Studio Code**.
2. Open this folder in VS Code. Open Terminal → New Terminal.
3. Create and activate a virtual environment:
   - Windows PowerShell: `py -m venv .venv` then `.\.venv\Scripts\Activate.ps1`
   - If PowerShell blocks activation, use CMD: `.venv\Scripts\activate.bat`
4. Install packages: `python -m pip install -r requirements.txt`
5. Copy `.env.example` to `.env`, paste your Sepolia RPC URL, then run:
   `streamlit run app.py`

The app opens in your browser, usually at `http://localhost:8501`.

## Run tests
`python -m pytest -q`

## Important security notes
- Use only Sepolia test ETH. Never use a real wallet's private key.
- Keep `.env` and `data/keystore.json` private; they are ignored by Git.
- The keystore password is not saved by the app.
- This is an educational demo, not an audited production wallet.
- Fund the wallet only with Sepolia test ETH from a reputable testnet faucet.
