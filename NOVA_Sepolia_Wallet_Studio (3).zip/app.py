import json
import os
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from web3 import Web3

from wallet_core import (
    create_encrypted_wallet, load_encrypted_wallet, get_balance,
    build_and_sign_transfer, save_keystore, load_keystore,
)

load_dotenv()
st.set_page_config(page_title="NOVA Wallet", page_icon="◈", layout="wide")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: radial-gradient(circle at 12% 0%, #172b45 0, #0b1220 38%, #080d17 100%); color: #eef4ff; }
.block-container { max-width: 1180px; padding-top: 2.1rem; }
h1,h2,h3 { font-family: 'Space Grotesk', sans-serif !important; color: #f4f7ff !important; }
.hero { padding: 26px 30px; border: 1px solid #263b58; border-radius: 22px;
background: linear-gradient(115deg, rgba(25,48,76,.96), rgba(15,26,43,.94));
box-shadow: 0 18px 55px rgba(0,0,0,.25); margin-bottom: 20px; }
.brand { color:#78e5d1; font-weight:700; letter-spacing: .16em; font-size: .78rem; }
.hero-title { font-family:'Space Grotesk'; font-size:2.25rem; font-weight:700; margin:.3rem 0; }
.muted { color:#9eb0c8; }
.metric { background:rgba(18,31,50,.88); border:1px solid #263b58; padding:20px 22px; border-radius:18px; min-height:112px; }
.metric-label { color:#9eb0c8; font-size:.82rem; }
.metric-value { font-family:'Space Grotesk'; font-size:1.55rem; font-weight:700; margin-top:8px; color:#f4f7ff; }
.panel { background:rgba(14,25,41,.88); border:1px solid #263b58; border-radius:18px; padding:22px; margin: 12px 0; }
div.stButton > button { border-radius:12px; border:0; background:linear-gradient(90deg,#64ddc6,#7db8ff); color:#081321; font-weight:700; min-height:2.8rem; }
div[data-testid="stTextInput"] input, div[data-testid="stTextArea"] textarea { background:#101d30; color:#eef4ff; border:1px solid #304765; border-radius:10px; }
.stTabs [data-baseweb="tab"] { color:#c5d2e5; }
small { color:#9eb0c8; }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <div class="brand">NOVA · WEB3 WALLET</div>
  <div class="hero-title">Your testnet wallet, beautifully simple.</div>
  <div class="muted">A student project for creating an encrypted wallet and sending test ETH on Sepolia.</div>
</div>
""", unsafe_allow_html=True)

rpc_url = os.getenv("SEPOLIA_RPC_URL", "").strip()
keystore_path = Path("data/keystore.json")
keystore_path.parent.mkdir(exist_ok=True)

if "account" not in st.session_state:
    st.session_state.account = None
if "private_key" not in st.session_state:
    st.session_state.private_key = None

w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 12})) if rpc_url else None
connected = bool(w3 and w3.is_connected())

c1, c2, c3 = st.columns(3)
with c1:
    st.markdown('<div class="metric"><div class="metric-label">NETWORK</div><div class="metric-value">Sepolia</div><small>Ethereum test network</small></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="metric"><div class="metric-label">RPC STATUS</div><div class="metric-value">{"Connected" if connected else "Not connected"}</div><small>{"Ready for testnet requests" if connected else "Set SEPOLIA_RPC_URL in .env"}</small></div>', unsafe_allow_html=True)
with c3:
    st.markdown(f'<div class="metric"><div class="metric-label">WALLET FILE</div><div class="metric-value">{"Found" if keystore_path.exists() else "Not created"}</div><small>Encrypted local keystore</small></div>', unsafe_allow_html=True)

if not rpc_url:
    st.warning("Add your Sepolia RPC URL to the .env file. You can still create an encrypted wallet in the meantime.")
elif not connected:
    st.error("Could not connect to the Sepolia RPC endpoint. Check the URL and your internet connection.")

tab1, tab2, tab3 = st.tabs(["  Wallet  ", "  Send test ETH  ", "  About project  "])

with tab1:
    left, right = st.columns([1.05, .95], gap="large")
    with left:
        st.markdown("### Create a wallet")
        st.write("Generate a new Ethereum address and save its private key in an encrypted keystore.")
        password = st.text_input("Keystore password", type="password", key="create_password", help="Use a strong password and keep it private.")
        confirm = st.text_input("Confirm password", type="password", key="confirm_password")
        if st.button("Create encrypted wallet", use_container_width=True):
            if len(password) < 8:
                st.error("Use a password with at least 8 characters.")
            elif password != confirm:
                st.error("Passwords do not match.")
            else:
                try:
                    account, encrypted = create_encrypted_wallet(password)
                    save_keystore(encrypted, keystore_path)
                    st.session_state.account = account.address
                    st.session_state.private_key = account.key.hex()
                    st.success("Wallet created and encrypted locally.")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Wallet creation failed: {exc}")

        st.markdown("---")
        st.markdown("### Unlock existing wallet")
        unlock_password = st.text_input("Password to unlock", type="password", key="unlock_password")
        if st.button("Unlock wallet", use_container_width=True):
            try:
                encrypted = load_keystore(keystore_path)
                account = load_encrypted_wallet(encrypted, unlock_password)
                st.session_state.account = account.address
                st.session_state.private_key = account.key.hex()
                st.success("Wallet unlocked for this session.")
                st.rerun()
            except FileNotFoundError:
                st.error("No keystore found. Create a wallet first.")
            except Exception:
                st.error("Could not unlock wallet. Check your password and keystore file.")

    with right:
        st.markdown("### Wallet overview")
        if st.session_state.account:
            st.markdown('<div class="panel">', unsafe_allow_html=True)
            st.markdown("**Wallet address**")
            st.code(st.session_state.account)
            if connected:
                try:
                    balance = get_balance(w3, st.session_state.account)
                    st.markdown(f'<div class="metric-label">AVAILABLE BALANCE</div><div class="metric-value">{balance:.6f} ETH</div>', unsafe_allow_html=True)
                except Exception as exc:
                    st.warning(f"Balance lookup failed: {exc}")
            else:
                st.info("Connect to Sepolia to display the live balance.")
            st.markdown("</div>", unsafe_allow_html=True)
            if st.button("Lock wallet", use_container_width=True):
                st.session_state.account = None
                st.session_state.private_key = None
                st.rerun()
        else:
            st.info("Create or unlock a wallet to see its address and balance.")
        st.caption("Security note: the keystore is encrypted on your computer. The password is never saved by this app. This is an educational testnet project.")

with tab2:
    st.markdown("### Transfer test ETH")
    st.write("Send Sepolia test ETH to another address. This app does not use real funds.")
    sender = st.session_state.account
    if not sender or not st.session_state.private_key:
        st.info("Create or unlock your wallet in the Wallet tab first.")
    elif not connected:
        st.warning("Connect to Sepolia using SEPOLIA_RPC_URL before sending.")
    else:
        st.caption(f"From: {sender}")
        recipient = st.text_input("Recipient address", placeholder="0x...")
        amount = st.number_input("Amount (Sepolia ETH)", min_value=0.000001, value=0.001, step=0.001, format="%.6f")
        if st.button("Prepare and send test transaction", use_container_width=True):
            try:
                if not Web3.is_address(recipient):
                    raise ValueError("Recipient address is not valid.")
                tx_hash = build_and_sign_transfer(w3, st.session_state.private_key, recipient, amount)
                st.success("Transaction sent to Sepolia.")
                st.code(tx_hash)
                st.markdown(f"[View transaction on Sepolia Etherscan](https://sepolia.etherscan.io/tx/{tx_hash})")
            except Exception as exc:
                st.error(f"Transaction failed: {exc}")

with tab3:
    st.markdown("### Project scope")
    st.markdown("""
    <div class="panel">
    <b>Topic 3 — Wallet for a test network</b><br><br>
    • Create an Ethereum address (public/private key pair).<br>
    • Store the private key in an encrypted keystore file.<br>
    • Connect to Sepolia using web3.py.<br>
    • Read the wallet balance.<br>
    • Send test ETH and open the transaction in Sepolia Etherscan.<br>
    • Keep secrets outside source code using a local <code>.env</code> file.
    </div>
    """, unsafe_allow_html=True)
    st.warning("Use only Sepolia test ETH. Never enter a real wallet's private key or fund this student app with real cryptocurrency.")
    st.write("The app keeps the unlocked key in Streamlit's session memory only. Lock the wallet or close the app when finished.")
